﻿using System;

namespace Inheritance_Demo_5
{

    //Differences between Interfaces and Abstract Classes. 

    /*
     An Abstract Class is a way to achieve the abstraction in C#.
    An Abstract class is never intended to be instntiated directly.
    This class must contain at least one abstract method, which is marked by the keyword or modifier abstract in the class definition. 
        A user must use the abstract class at the time of inheritance.
            the abstract class is used to inherit in the child class. 
        it can contain constructors.
        it can implement functions with non-abstract methods. <---significant
        it cannot support multiple inheritance.
        it can't be static. 

     Like a class, Interfaces can have methods, properties, events, and indexers as its members. 
    But interfaces will contain only the declaration of the members. 

    The implementation of the interfaces members will be given by the calss who implements the interfave implicitly or explicitly. 

    Advantage of interface:
        can achieve loose coupling
        can achieve total abstraction
        can achieve componenet-based programming
        can achieve multiple inheritance and abstraction
        interfaces add a plug and play like architecture into applications. 
     */
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

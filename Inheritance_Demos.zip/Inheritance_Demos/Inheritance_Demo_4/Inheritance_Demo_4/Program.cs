﻿using System;

namespace Inheritance_Demo_4
{
    //Interfaces 

    /*
     an interface defines a contract.
    Ant class or dtructdthat impliments that contract must provide an implementation of the members defined in th interface.

    used for dependancy injection
    used when you want two fundamentally different classes to behave polymorphically. 
     */
    class Program
    {
        static void Main(string[] args)
        {
           ImplementationClass obj = new ImplementationClass();
            obj.SampleMethod();


            Console.WriteLine("----------------------");

            Bicycle bicycle = new Bicycle();
            bicycle.ApplyBreaks(1);
            bicycle.SpeedUp(3);
            bicycle.ChangeGear(5);

            Console.WriteLine("bicycle current state: ");
            bicycle.PrintState();

            Console.WriteLine("----------------");
            
            Car car = new Car();

            car.ChangeGear(1);
            car.SpeedUp(4);
            car.ApplyBreaks(1);
            Console.WriteLine("car current state: ");
            car.PrintState();

         
        }
        
    }

    interface ISampleInterface
    {
        void SampleMethod();
    }


    class ImplementationClass : ISampleInterface
    {
        public void SampleMethod()
        {
            Console.WriteLine("Do something interfacie....");
        }
    }

    interface IVehicle
    {
        void ChangeGear(int a);
        void SpeedUp(int a);
        void ApplyBreaks(int a);
        void WashVehicle();

    }

    class Bicycle : IVehicle
    {
        int speed, gear;

        public void ApplyBreaks(int decrement)
        {
            speed = speed - decrement;
        }

        public void ChangeGear(int newGear)
        {
            gear = newGear;
        }

        public void SpeedUp(int increment)
        {
            speed = speed + increment;
        }

        public void WashVehicle()
        {
            Console.WriteLine("Washing the bike!!" );
        }

        public void PrintState()
        {

            Console.WriteLine("speed: " + speed + "gear:" + gear);
        }
    }

    class Car : IVehicle
    {
        int speed;
        int gear;


        public void ApplyBreaks(int decrement)
        {
            speed = speed - decrement;
        }

        public void ChangeGear(int newGear)
        {
            gear = newGear;
        }

        public void SpeedUp(int increment)
        {
            speed = speed + (increment * 2);
        }

        public void WashVehicle()
        {
            Console.WriteLine("The car has been washed. ");
        }

        public void PrintState()
        {

            Console.WriteLine("speed: " + speed + "gear:" + gear);
        }
    }

}

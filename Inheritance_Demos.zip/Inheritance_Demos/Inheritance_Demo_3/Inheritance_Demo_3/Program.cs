﻿using System;

namespace Inheritance_Demo_3
{
    class Program
    {
        /*
            Creating and using abstract methods/classes
        
        Virtual methods have an implementation and provide the derived classes with the option of overriding it. 
        Abstract methods do not provide an implementation and force the dervice classes to override the method. 

        So,Abstract methods have no actual code in them, subclasses HAVE TO override the method.

        Virtual methods can have code, which is usuall default implementaion of somethin and any subclasses 
        CAN override the method using the overide modifier and provide a custom implementation. 

         */

        static void Main(string[] args)
        {
            var cat = new Cat();
            cat.Walk();
            cat.Feed();
            Console.WriteLine("------------------");


            var dog = new Dog();
            dog.Walk();
            dog.Feed();


        }



    }

    abstract class Animal
    {
        public abstract void Walk();

        public void Feed() 
        {
            Console.WriteLine("Time to feed the animals....");
        }
    }

    class Cat : Animal
    {
        public override void Walk()
        {
            Console.WriteLine("The cat is walking....");
        }
    }

    class Dog : Animal
    {
        public override void Walk()
        {
            Console.WriteLine("The Dog is walking......");
        }
    }
}

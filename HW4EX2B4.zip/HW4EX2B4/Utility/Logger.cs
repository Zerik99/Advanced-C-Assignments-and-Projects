using System;

namespace HW4EX2B4.Utility
{
    public static class Logger
    {
        public static void Error(string message, Exception exception)
        {
        }
    }
}
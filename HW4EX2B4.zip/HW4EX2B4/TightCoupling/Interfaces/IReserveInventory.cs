using HW4EX2B4.TightCoupling.Interfaces;
namespace HW4EX2B4.TightCoupling.Model
{
    public interface IReserveInventory
    {
        void ReserveInventory(Cart cart);
    }
}
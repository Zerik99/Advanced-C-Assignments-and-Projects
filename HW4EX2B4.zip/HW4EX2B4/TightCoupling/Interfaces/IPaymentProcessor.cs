using HW4EX2B4.TightCoupling.Interfaces;
namespace HW4EX2B4.TightCoupling.Model
{
    public interface IPaymentProcessor
    {
        void ChargeCard(ICardDetails paymentDetails, decimal amount);
    }
}
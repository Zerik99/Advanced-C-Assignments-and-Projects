﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4EX2B4.TightCoupling.Interfaces
{
    interface IOrderItem
    {
        string Sku { get; set; }
        int Quantity { get; set; }
    }
}

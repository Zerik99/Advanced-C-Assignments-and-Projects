﻿using System;
using HW4EX2B4.TightCoupling.Model;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4EX2B4.TightCoupling.Interfaces
{
    public interface ICardDetails
    {
        PaymentMethod PaymentMethod { get; set; }
        string CreditCardNumber { get; set; }

        string ExpiresMonth { get; set; }

        string ExpiresYear { get; set; }

        string CardholderName { get; set; }
    }
}

using HW4EX2B4.TightCoupling.Interfaces;
namespace HW4EX2B4.TightCoupling.Model
{
    public interface INotifyCustomer
    {
        void NotifyCustomer(Cart cart);

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4EX2B4.TightCoupling.Interfaces
{
    interface IInventorySystem
    {
        void Reserve(string sku, int quantity);
    }
}

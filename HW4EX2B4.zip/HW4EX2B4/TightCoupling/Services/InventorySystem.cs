using System;
using HW4EX2B4.TightCoupling.Interfaces;
namespace HW4EX2B4.TightCoupling.Services
{
    public class InventorySystem: IInventorySystem
    {
        public void Reserve(string sku, int quantity)
        {
            throw new InsufficientInventoryException();
        }
    }

    public class InsufficientInventoryException : Exception
    {
    }
}
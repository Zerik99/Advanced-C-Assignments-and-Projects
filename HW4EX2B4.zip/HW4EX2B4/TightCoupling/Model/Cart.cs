using System.Collections.Generic;

using HW4EX2B4.TightCoupling.Interfaces;

namespace HW4EX2B4.TightCoupling.Model
{
    public class Cart: ICart
    {     
        public IEnumerable<OrderItem> Items { get; set; }
        public decimal Total { get; set; }
        public string CustomerEmail { get; set; }

        public Cart()
        {
            this.Items = new List<OrderItem>();
        }
    }
}
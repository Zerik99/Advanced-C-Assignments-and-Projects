﻿using System;
using HW4EX2B4.TightCoupling.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4EX2B4.TightCoupling.Model
{
    public class StartUp
    {
        public static IServiceProvider StartUpService() 
        {
            var provider = new ServiceCollection()
                .AddSingleton<INotifyCustomer, NotifyCustomerService> ()
                .AddSingleton<IReserveInventory, ReserveInventoryService>()
                .AddSingleton<IPaymentProcessor, PaymentProcessorService>()
                .AddSingleton<ICardDetails, PaymentDetails>()
                .AddSingleton<IOrderItem, OrderItem>()
                .BuildServiceProvider();
                return provider;
            
        }
    }
}

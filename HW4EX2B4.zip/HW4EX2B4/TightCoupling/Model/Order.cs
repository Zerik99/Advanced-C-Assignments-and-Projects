using HW4EX2B4.TightCoupling.Interfaces;
using HW4EX2B4.TightCoupling.Services;
using Microsoft.Extensions.DependencyInjection;

namespace HW4EX2B4.TightCoupling.Model
{
    public class Order
    {
        
        private readonly Cart _cart;
        private readonly ICardDetails _paymentDetails;
        private readonly INotifyCustomer _notifyCustomer;
        private readonly IReserveInventory _reserveInventory;
        private readonly IPaymentProcessor _paymentProcessor;
        



        /*
            Dependency Inversion Principle
         *  High-level modules should not depend on low-level modules. Both should depend on abstractions. 
            Abstractions should not depend on details. Details should depend on abstractions
         */
        
        public Order(Cart cart, ICardDetails cardDetails, INotifyCustomer notifyCustomer, IReserveInventory reserveInventory, IPaymentProcessor paymentProcessor)
        {
            var diContainer = StartUp.StartUpService();
            
            _paymentDetails = diContainer.GetRequiredService<ICardDetails>();
            _notifyCustomer = diContainer.GetRequiredService<INotifyCustomer>();
            _reserveInventory = diContainer.GetRequiredService<IReserveInventory>();
            _paymentProcessor = diContainer.GetRequiredService<IPaymentProcessor>();
            _cart = cart;


        }
    


        public void Checkout(bool notifyCustomer)
        {
            
            
            if (_paymentDetails.PaymentMethod == PaymentMethod.CreditCard)
            { 
                _paymentProcessor.ChargeCard(_paymentDetails, _cart.Total);
            }

            _reserveInventory.ReserveInventory(_cart);

            if (notifyCustomer)
            {
                _notifyCustomer.NotifyCustomer(_cart);
            }
        }
    }
}


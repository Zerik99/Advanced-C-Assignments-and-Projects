namespace HW4EX2B4.TightCoupling.Model
{
    public enum PaymentMethod
    {
        Cash,
        CreditCard
    }
}
using HW4EX2B4.TightCoupling.Interfaces;

namespace HW4EX2B4.TightCoupling.Model
{
    public class OrderItem : IOrderItem
    {
        public string Sku { get; set; }
        public int Quantity { get; set; }
    }
}
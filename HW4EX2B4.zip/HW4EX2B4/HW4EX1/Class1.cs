﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4EX2B4.HW4EX1
{
    class Program
    {
        static void Main(string[] args)
        {
            BurgerOrderService order = new BurgerOrderService();
            order.orderBurger(2);       // only want a burger only order
            order.orderFries(0);            // throws an exception
        }
    }


    interface IOrderCombo
    {
        void orderCombo(int quantity, int fries);
    }

    interface IOrderBurger 
    {
        void orderBurger(int quantity);
    }

    interface IOrderFries 
    {
        void orderFries(int fries);
    }

    public class BurgerOrderService : IOrderBurger, IOrderFries, IOrderCombo
    {
       
        public void orderBurger(int quantity)
        {
            Console.WriteLine($"Received order for {quantity} Burgers.");
        }

        public void orderFries(int fries)
        {
            Console.WriteLine($"Received order for {fries} Fries.");
        }

        public void orderCombo(int quantity, int fries)
        {
            Console.WriteLine($"Received order for {quantity} Burgers and {fries} Fries.");
        }
    }
}

using GrandTotal_exercise;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GrandTotal.UnitTests
{
    [TestClass]
    public class ProgramTests
    {
        [TestMethod]
        public void CreatePurchasableList_IncludesExpectedItems()
        {
            //Arrange
                         
            var purchasableListActual = Program.CreatePurchasableList();
            
            //Act
           
            //Assert
            CollectionAssert.AllItemsAreNotNull(purchasableListActual);
        }
        [TestMethod]
        public void FindTaxableItems_IncludesExpectedItems()
        {
            //Arrange
            var items = Program.CreatePurchasableList();
            var TaxableListActual = Program.FindTaxableItems(items);

            //Act

            //Assert
            CollectionAssert.AllItemsAreNotNull(TaxableListActual);
        }
        [TestMethod]
        public void FindShippableItems_IncludesExpectedItems()
        {
            //Arrange
            var items = Program.CreatePurchasableList();
            var shippableItemsActual = Program.FindShippableItems(items);
            //Act

            //Assert
            CollectionAssert.AllItemsAreNotNull(shippableItemsActual);
        }
        [TestMethod]
        public void CalculateGrandTotal_ReturnsExpectedValue() 
        {
            //Arrange
            double shippingRate = 5;
            double Tax = 1;
            double price = 10;
            double grandTotal;
            //Act
            grandTotal = Program.CalculateGrandTotal(shippingRate, Tax, price);
            //Assert
            Assert.AreEqual(16, grandTotal);
        }
        [TestMethod]
        public void CompleteTransaction_ReturnExpectedValue() 
        {
            //Assign
            var appointment = new Appointment()
            {
                Name = "James",
                StartDateTime = DateTime.Now.AddHours(1),
                EndDateTime = DateTime.Now.AddHours(2),
                Price = 100D
            };
            var book = new Book()
            {
                Title = "Welcome to Advanced C#",
                Price = 50D,
                TaxRate = 0.0825D,
                ShippingRate = 5D
            };
            var snack = new Snack()
            {
                Price = 2D
            };
            var tshirt = new TShirt()
            {
                Size = "2X",
                Price = 25D,
                TaxRate = 0.0625D,
                ShippingRate = 2
            };

            var items = new List<IPurchasable>();
            items.Add(appointment);
            items.Add(book);
            items.Add(snack);
            items.Add(tshirt);
            double completeTransaction;
            //Act
            completeTransaction = Program.CompleteTransaction(items);
            //Assert
            Assert.AreEqual(177, completeTransaction);
        }
        [TestMethod]
        public void CalculateShipping_ReturnExpectedValue()
        {
            //assign
            var appointment = new Appointment()
            {
                Name = "James",
                StartDateTime = DateTime.Now.AddHours(1),
                EndDateTime = DateTime.Now.AddHours(2),
                Price = 100D
            };
            var book = new Book()
            {
                Title = "Welcome to Advanced C#",
                Price = 50D,
                TaxRate = 0.0825D,
                ShippingRate = 5D
            };
            var snack = new Snack()
            {
                Price = 2D
            };
            var tshirt = new TShirt()
            {
                Size = "2X",
                Price = 25D,
                TaxRate = 0.0625D,
                ShippingRate = 2
            };

            var items = new List<IPurchasable>();
            items.Add(appointment);
            items.Add(book);
            items.Add(snack);
            items.Add(tshirt);

            var shippableItems = new List<IShippable>();
            foreach (var item in items)
            {
                if (item is IShippable)
                {
                    shippableItems.Add(item as IShippable);
                }
            }

            double shippingCost;
            //Act
            shippingCost = Program.CalculateShipping(shippableItems);
            //Assert
            Assert.AreEqual(7, shippingCost);
        }
        [TestMethod]
        public void CalculateTax_ReturnExpectedValue()
        {
            //assign
            var appointment = new Appointment()
            {
                Name = "James",
                StartDateTime = DateTime.Now.AddHours(1),
                EndDateTime = DateTime.Now.AddHours(2),
                Price = 100D
            };
            var book = new Book()
            {
                Title = "Welcome to Advanced C#",
                Price = 50D,
                TaxRate = 0.0825D,
                ShippingRate = 5D
            };
            var snack = new Snack()
            {
                Price = 2D
            };
            var tshirt = new TShirt()
            {
                Size = "2X",
                Price = 25D,
                TaxRate = 0.0625D,
                ShippingRate = 2
            };

            var items = new List<IPurchasable>();
            items.Add(appointment);
            items.Add(book);
            items.Add(snack);
            items.Add(tshirt);

            var taxableItems = new List<ITaxable>();
            foreach (var item in items)
            {
                if (item is ITaxable)
                {
                    taxableItems.Add(item as ITaxable);
                }
            }

            double tax;
            //Act
            tax = Program.CalculateTax(taxableItems);
            //Assert
            Assert.AreEqual(5.6875D, tax);
        }
    }
    [TestClass]
    public class BookTests
    {    
        [TestMethod]        
        public void Tax_TaxCalculation_AreEqual()
        {
            //arrange
            var Book = new Book()
            {
                Title = "Welcome to Advanced C#",
                Price = 50D,
                TaxRate = 0.0825D,
                ShippingRate = 5D
            };
            double tax; 
            double Price = Book.Price;
            double TaxRate = Book.TaxRate;
            //act
            
            tax = Price * TaxRate;

            //assert

            Assert.AreEqual(Book.Tax(), tax);

        }
        [TestMethod]
        public void Tax_TaxCalculation_AreNotNegative()
        {
            //arrange
            var Book = new Book()
            {
                Title = "Welcome to Advanced C#",
                Price = 50D,
                TaxRate = 0.0825D,
                ShippingRate = 5D
            };
            double tax;
            double negTax;
            double Price = Book.Price;
            double TaxRate = Book.TaxRate;
            //act

            tax = Price * TaxRate;

            negTax = tax - (tax * 2);
            //assert
            Assert.AreNotEqual(Book.Tax(), negTax);
        }

        [TestMethod]
        public void Tax_TaxCalculation_AreNotZero()
        {
            //arrange
            var Book = new Book()
            {
                Title = "Welcome to Advanced C#",
                Price = 50D,
                TaxRate = 0.0825D,
                ShippingRate = 5D
            };          
            
            //act
            
            //assert
            Assert.AreNotEqual(Book.Tax(), 0D);

        }


    }
    [TestClass]
    public class TshirtTests
    {
        [TestMethod]
        public void Tax_TaxCalculation_AreEqual()
        {
            //arrange
            var tshirt = new TShirt()
            {
                Size = "2X",
                Price = 25D,
                TaxRate = 0.0625D,
                ShippingRate = 2
            };
            double tax;
            double Price = tshirt.Price;
            double TaxRate = tshirt.TaxRate;
            //act

            tax = Price * TaxRate;

            //assert

            Assert.AreEqual(tshirt.Tax(), tax);

        }

        [TestMethod]
        public void Tax_TaxCalculation_AreNotNegative()
        {
            //arrange
            var tshirt = new TShirt()
            {
                Size = "2X",
                Price = 25D,
                TaxRate = 0.0625D,
                ShippingRate = 2
            };
            double tax;
            double negTax;
            double Price = tshirt.Price;
            double TaxRate = tshirt.TaxRate;
            //act

            tax = Price * TaxRate;

            negTax = tax - (tax * 2);
            //assert
            Assert.AreNotEqual(tshirt.Tax(), negTax);

        }

        [TestMethod]
        public void Tax_TaxCalculation_AreNotZero()
        {
            //arrange
            var tshirt = new TShirt()
            {
                Size = "2X",
                Price = 25D,
                TaxRate = 0.0625D,
                ShippingRate = 2
            };

          
            //act
           
            //assert
            Assert.AreNotEqual(tshirt.Tax(), 0);

        }


    }
   
}

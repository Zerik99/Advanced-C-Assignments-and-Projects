﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace UnitTestDemo.Test
{
    [TestClass]
    public class AssertClassTest
    {
        #region AreEqual/AreNotEqual Tests

        [TestMethod]
        public void AreEqualTest()
        {
            string str1 = "GoBears";
            string str2 = "GoBears";

            Assert.AreEqual(expected: str1, actual: str2);
        }

        [TestMethod]
        [ExpectedException(typeof(AssertFailedException))]
        public void AreEqualCaseSensitiveTest()
        {
            string str1 = "GoBears";
            string str2 = "goBears";

            Assert.AreEqual(expected: str1, actual: str2, ignoreCase:false);
        }

        [TestMethod]
        public void AreNotEqualTest()
        {
            string str1 = "MissouriState";
            string str2 = "MSU";

            Assert.AreNotEqual(str1, actual: str2);
        }


        #endregion

        #region AreSame/AreNotSame tests

        [TestMethod]
        public void AreSameTest() 
        {
            FileProcess x = new FileProcess();
            FileProcess y = x;

            Assert.AreSame(expected: x, actual: y);



        }

        [TestMethod]
        public void AreNotSameTest()
        {
            FileProcess x = new FileProcess();
            FileProcess y = new FileProcess(); ;

            Assert.AreNotSame(x, actual: y);



        }


        #endregion

    }
}

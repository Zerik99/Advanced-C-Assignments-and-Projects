using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestDemo.Test
{
    [TestClass]
    public class FileProcessTest
    {
        [TestMethod]
        public void FileNameDoesExist() 
        {
            //Arrange
            // in the future we will explore different ways to reference other projects
            FileProcess fp = new FileProcess();
            bool fromCall;

            //Act

            fromCall = fp.FileExists(fileName:@"C:\windows\regedit.exe");

            //Assert

            Assert.IsTrue(fromCall);

        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void FileNameDoesNotExist() 
        {
            //Arrange
            // in the future we will explore different ways to reference other projects
            FileProcess fp = new FileProcess();
            bool fromCall;

            //Act

            fromCall = fp.FileExists(fileName: @"");

            //Assert

            Assert.IsFalse(fromCall);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace UnitTestDemo
{
    public class FileProcess
    {
        public bool FileExists(String fileName) 
        {

            if (string.IsNullOrEmpty(fileName)) 
            {
                throw new ArgumentNullException(paramName: "fileName");
            }
            return File.Exists(fileName);
        }

    }
}
